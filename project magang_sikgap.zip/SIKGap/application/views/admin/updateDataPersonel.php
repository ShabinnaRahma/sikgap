<div class="container-fluid">

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
</div>


<div class="card" style="width: 60%; margin-bottom: 100px">
    <div class="card-body">
   
        <?php foreach ($personel as $j): ?>
        <form method="POST" action="<?php echo base_url('admin/dataPersonel/updateDataAksi') ?>">

        <div class="form-group">
            <label>Nama Personel</label>
            <input type="hidden" name="nama_personel" class="form-control" value="<?php echo $j->nama_personel ?>"></input>
            <input type="text" name="nama_personel" class="form-control" value="<?php echo $j->nama_personel ?>"></input>
            <?php echo form_error('nama_personel','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Pangkat</label>
            <input type="text" name="pangkat" class="form-control" value="<?php echo $j->pangkat ?>"></input>
            <?php echo form_error('pangkat','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>NRP/NIP</label>
            <input type="hidden" name="id_personel" class="form-control" value="<?php echo $j->id_personel ?>"></input>
            <input type="text" name="NRP" class="form-control" value="<?php echo $j->NRP ?>"></input>
            <?php echo form_error('NRP','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Jabatan</label>
            <input type="text" name="jabatan" class="form-control" value="<?php echo $j->jabatan ?>"></input>
            <?php echo form_error('jabatan','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control" >
                <option value="<?php echo $j->jenis_kelamin ?>"><?php echo $j->jenis_kelamin ?></option>
                <option value="Laki-Laki">Laki-Laki</option>
                <option value="Perempuan">Perempuan</option>
            </select>
            <?php echo form_error('jenis_kelamin','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" class="form-control" value="<?php echo $j->tanggal_lahir?>"></input>
            <?php echo form_error('tanggal_lahir','<div class="text-small text-danger"></div>') ?>
        </div>


        <button types="submit" class="btn btn-success"> Update</button>

        </form>
        <?php endforeach; ?>
    </div>

</div>



</div>
