<div class="container-fluid">

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
</div>

<div class="card" style="width: 60%; margin-bottom: 100px">
    <div class="card-body">
   
        <?php foreach ($pensiun as $a): ?>
        <form method="POST" action="<?php echo base_url('admin/prosesPensiun/updateDataAksi') ?>">

        <div class="form-group">
            <label>Nama Personel</label>
            <input type="hidden" name="nama_personel" class="form-control" value="<?php echo $a->nama_personel ?>"></input>
            <input type="text" name="nama_personel" class="form-control" value="<?php echo $a->nama_personel ?>"></input>
            <?php echo form_error('nama_personel','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>NRP/NIP</label>
            <input type="hidden" name="NRP" class="form-control" value="<?php echo $a->NRP?>"></input>
            <input type="text" name="NRP" class="form-control" value="<?php echo $a->NRP ?>"></input>
            <?php echo form_error('NRP','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Usia</label>
            <input type="text" name="usia" class="form-control" value="<?php echo $a->usia ?>"></input>
            <?php echo form_error('usia','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>TMT Pensiun</label>
            <input type="date" name="tmt_pensiun" class="form-control" value="<?php echo $a->tmt_pensiun?>"></input>
            <?php echo form_error('tmt_pensiun','<div class="text-small text-danger"></div>') ?>
        </div>


        <button types="submit" class="btn btn-success"> Update</button>

        </form>
        <?php endforeach; ?>
    </div>

</div>



</div>