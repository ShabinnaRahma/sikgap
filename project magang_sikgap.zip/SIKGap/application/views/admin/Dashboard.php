<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>

    <!-- Content Row -->
    <div class="row">
        <!-- Data Personel-->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2" style="z-index: 1;">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Jumlah Personel</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $personel ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Data Admin -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2" style="z-index: 1;">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Jumlah Admin</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $admin ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-user-tie fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="background-content">
        <div class="col">
            <h6 class="background-text">APLIKASI SIKGAP<br>(Sistem Informasi Kenaikan Gaji Berkala, Kenaikan Pangkat dan Pensiun )</h6>
            <img src="<?= base_url('assets/img/bid tik.png') ?>" alt="Bid TIK" class="background-image">
        </div>
    </div>

    <?php if ($this->session->flashdata('pesan')) {
        if (!empty($notifications)) {
    ?>
            <div class="modal" id="notification-modal" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Notifikasi</h5>
                            <button type="button" class="close close-btn" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <h5 class="mb-3">Daftar personel dengan proses terdekat:</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama Personel</th>
                                        <th scope="col">Tipe Proses</th>
                                        <th scope="col">Tanggal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $index = 1 ?>
                                    <?php foreach ($notifications as $item) { ?>
                                        <tr>
                                            <th scope="row"><?= $index ?></th>
                                            <td><?= $item->nama_personel ?></td>
                                            <?php if ($item->source == 'KGB') { ?>
                                                <td>Kenaikan Gaji Berkala (KGB)</td>
                                            <?php } else if ($item->source == 'Pangkat') { ?>
                                                <td>Naik Pangkat</td>
                                            <?php } else if ($item->source == 'Pensiun') { ?>
                                                <td>Pensiun</td>
                                            <?php } else { ?>
                                                <td>-</td>
                                            <?php } ?>
                                            <td><?= $item->date ?> (<?= $item->remaining_days ?>)</td>
                                        </tr>
                                    <?php $index++;
                                    } ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary close-btn" data-dismiss="modal">Tutup</button>
                        </div>
                    </div>
                </div>
            </div>
    <?php }
    } ?>


</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Fetch flashdata from embedded PHP
        var pesan = "<?php echo $this->session->flashdata('pesan'); ?>";

        console.log(pesan);

        if (pesan) {
            // Show the modal by adding 'show' and 'display' classes
            var modal = document.getElementById('notification-modal');
            modal.classList.add('show');
            modal.style.display = 'block';
            modal.setAttribute('aria-modal', 'true');
            modal.removeAttribute('aria-hidden');

            // Add a backdrop manually
            var backdrop = document.createElement('div');
            backdrop.id = 'modal-backdrop';
            backdrop.className = 'modal-backdrop fade show';
            document.body.appendChild(backdrop);
        }

        var closeButtons = document.querySelectorAll('.close-btn');
        closeButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                // Hide the modal by removing 'show' class and setting display to 'none'
                var modal = document.getElementById('notification-modal');
                modal.classList.remove('show');
                modal.style.display = 'none';
                modal.removeAttribute('aria-modal');
                modal.setAttribute('aria-hidden', 'true');

                // Remove the backdrop
                var backdrop = document.getElementById('modal-backdrop');
                if (backdrop) {
                    backdrop.parentNode.removeChild(backdrop);
                }
            });
        });
    });
</script>

<style>
    .background-content {
        position: relative;
        text-align: center;
        color: white;
        margin-top: 20px;
        z-index: 0;
    }

    .background-text {
        color: grey;
        font-weight: bold;
        font-size: 1.2rem;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -40%);
        pointer-events: none;
        user-select: none;
        position: absolute;
    }

    .background-image {
        width: 100%;
        max-width: 300px;
        height: auto;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, 3%);
        z-index: 0;
        opacity: 0.3;
        pointer-events: none;
    }

    @media (max-width: 768px) {
        .background-text {
            font-size: 14px;
        }

        .background-image {
            width: 80%;
            max-width: 200px;
        }
    }
</style>