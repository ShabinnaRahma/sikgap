<div class="container-fluid">

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
</div>

<div class="card" style="width: 60%; margin-bottom: 100px">
    <div class="card-body">
   
        <?php foreach ($pangkat as $a): ?>
        <form method="POST" action="<?php echo base_url('admin/prosesPangkat/updateDataAksi') ?>">

        <div class="form-group">
            <label>Nama Personel</label>
            <input type="hidden" name="nama_personel" class="form-control" value="<?php echo $a->nama_personel ?>"></input>
            <input type="text" name="nama_personel" class="form-control" value="<?php echo $a->nama_personel ?>"></input>
            <?php echo form_error('nama_personel','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>NRP/NIP</label>
            <input type="hidden" name="NRP" class="form-control" value="<?php echo $a->NRP?>"></input>
            <input type="text" name="NRP" class="form-control" value="<?php echo $a->NRP ?>"></input>
            <?php echo form_error('NRP','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Pangkat Terakhir</label>
            <input type="text" name="pangkat_terakhir" class="form-control" value="<?php echo $a->pangkat_terakhir ?>"></input>
            <?php echo form_error('pangkat_terakhir','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>TMT Terakhir</label>
            <input type="date" name="tmt_terakhir" class="form-control" value="<?php echo $a->tmt_terakhir?>"></input>
            <?php echo form_error('tmt_terakhir','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Pangkat Selanjutnya</label>
            <input type="text" name="pangkat_selanjutnya" class="form-control" value="<?php echo $a->pangkat_selanjutnya ?>"></input>
            <?php echo form_error('pangkat_selanjutnya','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>TMT Selanjutnya</label>
            <input type="date" name="tmt_selanjutnya" class="form-control" value="<?php echo $a->tmt_selanjutnya?>"></input>
            <?php echo form_error('tmt_selanjutnya','<div class="text-small text-danger"></div>') ?>
        </div>


        <button types="submit" class="btn btn-success"> Update</button>

        </form>
        <?php endforeach; ?>
    </div>

</div>



</div>