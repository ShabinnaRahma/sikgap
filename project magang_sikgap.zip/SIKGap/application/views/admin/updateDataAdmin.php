<div class="container-fluid">

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
</div>


<div class="card" style="width: 60%; margin-bottom: 100px">
    <div class="card-body">
   
        <?php foreach ($admin as $j): ?>
        <form method="POST" action="<?php echo base_url('admin/dataAdmin/updateDataAksi') ?>">

        <div class="form-group">
            <label>Nama Admin</label>
            <input type="hidden" name="nama_admin" class="form-control" value="<?php echo $j->nama_admin ?>"></input>
            <input type="text" name="nama_admin" class="form-control" value="<?php echo $j->nama_admin ?>"></input>
            <?php echo form_error('nama_admin','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>NRP/NIP</label>
            <input type="hidden" name="id_admin" class="form-control" value="<?php echo $j->id_admin ?>"></input>
            <input type="text" name="NRP" class="form-control" value="<?php echo $j->NRP ?>"></input>
            <?php echo form_error('NRP','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Hak Akses</label>
            <input type="text" name="hak_akses" class="form-control" value="<?php echo $j->hak_akses ?>"></input>
            <?php echo form_error('hak_akses','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" value="<?php echo $j->password?>"></input>
            <?php echo form_error('password','<div class="text-small text-danger"></div>') ?>
        </div>


        <button types="submit" class="btn btn-success"> Update</button>

        </form>
        <?php endforeach; ?>
    </div>

</div>



</div>
