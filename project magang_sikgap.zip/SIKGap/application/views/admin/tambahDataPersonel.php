<div class="container-fluid">

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
</div>


<div class="card" style="width: 60%; margin-bottom: 100px">
    <div class="card-body">

        <form method="POST" action="<?php echo base_url('admin/dataPersonel/tambahDataAksi') ?>">
        <div class="form-group">
            <label>Nama Personel</label>
            <input type="text" name="nama_personel" class="form-control">
            <?php echo form_error('nama_personel','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Pangkat</label>
            <input type="text" name="pangkat" class="form-control">
            <?php echo form_error('pangkat','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>NRP/NIP</label>
            <input type="text" name="NRP" class="form-control">
            <?php echo form_error('NRP','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Jabatan</label>
            <input type="text" name="jabatan" class="form-control">
            <?php echo form_error('jabatan','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control">
                <option value="">--Pilih Jenis Kelamin--</option>
                <option value="Laki-Laki">Laki-Laki</option>
                <option value="Perempuan">Perempuan</option>
            </select>
            <?php echo form_error('jenis_kelamin','<div class="text-small text-danger"></div>') ?>
        </div>
        <div class="form-group">
            <label>Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" class="form-control">
            <?php echo form_error('tanggal_lahir','<div class="text-small text-danger"></div>') ?>
        </div>


        <button types="submit" class="btn btn-success">Submit</button>

        </form>
    </div>

</div>



</div>
