<div class="container-fluid">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
    </div>

    <div class="card mb-3">
        <div class="card-header bg-primary text-white">
            Filter Data Proses Pensiun
        </div>
        <div class="card-body">
            <form class="form-inline">
                <div class="form-group mb-2">
                    <label for="nrp"> Cari NRP/NIP : </label>
                    <input type="text" name="nrp" class="form-control ml-2" value="<?= !empty($nrp) ? $nrp : '' ?>">
                    <?php echo form_error('NRP', '<div class="text-small text-danger"></div>') ?>
                </div>
                <div class="form-group mb-2 mx-auto">
                    <label for="nama"> Cari Nama : </label>
                    <input type="text" name="nama" class="form-control ml-2" value="<?= !empty($nama) ? $nama : '' ?>">
                    <?php echo form_error('NAMA', '<div class="text-small text-danger"></div>') ?>
                </div>
                <button type="submit" class="btn btn-primary mb-2 ml-auto"><i class="fas fa-eye"></i>Tampilkan Data</button>
            </form>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-header bg-primary text-white">
            Filter Data Proses Pensiun
        </div>
        <div class="card-body">

            <form class="form-inline">
                <div class="form-group mb-2">
                    <label for="staticEmail2">Bulan : </label>
                    <select class="form-control ml-2" name="bulan">
                        <option value="">--Pilih Bulan--</option>
                        <option value="01" <?= !empty($bulan) && $bulan == '01' ? 'selected' : '' ?>>Januari</option>
                        <option value="02" <?= !empty($bulan) && $bulan == '02' ? 'selected' : '' ?>>Februari</option>
                        <option value="03" <?= !empty($bulan) && $bulan == '03' ? 'selected' : '' ?>>Maret</option>
                        <option value="04" <?= !empty($bulan) && $bulan == '04' ? 'selected' : '' ?>>April</option>
                        <option value="05" <?= !empty($bulan) && $bulan == '05' ? 'selected' : '' ?>>Mei</option>
                        <option value="06" <?= !empty($bulan) && $bulan == '06' ? 'selected' : '' ?>>Juni</option>
                        <option value="07" <?= !empty($bulan) && $bulan == '07' ? 'selected' : '' ?>>Juli</option>
                        <option value="08" <?= !empty($bulan) && $bulan == '08' ? 'selected' : '' ?>>Agustus</option>
                        <option value="09" <?= !empty($bulan) && $bulan == '09' ? 'selected' : '' ?>>September</option>
                        <option value="10" <?= !empty($bulan) && $bulan == '10' ? 'selected' : '' ?>>Oktober</option>
                        <option value="11" <?= !empty($bulan) && $bulan == '11' ? 'selected' : '' ?>>November</option>
                        <option value="12" <?= !empty($bulan) && $bulan == '12' ? 'selected' : '' ?>>Desember</option>
                    </select>
                </div>

                <div class="form-group mb-2 ml-5">
                    <label for="tahun">Tahun : </label>
                    <select class="form-control ml-2" name="tahun">
                        <option value="">--Pilih Tahun--</option>
                        <?php
                        for ($i = 2024; $i < date('Y') + 5; $i++) { ?>
                            <option <?= !empty($tahun) && $tahun == $i ? 'selected' : '' ?> value="<?= $i ?>"><?= $i ?></option>
                        <?php } ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary mb-2 ml-auto"><i class="fas fa-eye"></i>Tampilkan Data</button>
                <a href="<?php echo base_url('admin/prosesPensiun/inputPensiun') ?>" class="btn btn-success mb-2 ml-2"><i class="fas fa-plus"></i>Input Kenaikan Gaji Berkala</a>
            </form>
        </div>
    </div>


    <div class="alert alert-info">
        <?php
        if (!empty($nrp) && !empty($nama)) {
        ?>
            Menampilkan Data Pensiun Berdasarkan Pencarian NRP : <span class="font-weight-bold"><?php echo $nrp ?></span> dan Nama : <span class="font-weight-bold"><?php echo $nama ?></span>
        <?php
        } else  if (!empty($nrp) && empty($nama)) {
        ?>
            Menampilkan Data Pensiun Berdasarkan Pencarian NRP : <span class="font-weight-bold"><?php echo $nrp ?></span>
        <?php
        } else  if (empty($nrp) && !empty($nama)) {
        ?>
            Menampilkan Data Pensiun Berdasarkan Pencarian Nama : <span class="font-weight-bold"><?php echo $nama ?></span>
        <?php
        } else  if (empty($bulan) && !empty($tahun)) {
        ?>
            Menampilkan Data Pensiun Tahun : <span class="font-weight-bold"><?php echo $tahun ?></span>
        <?php
        } else if (!empty($bulan) && !empty($tahun)) {
        ?>
            Menampilkan Data Pensiun Bulan : <span class="font-weight-bold"><?php echo $bulan ?></span> Tahun : <span class="font-weight-bold"><?php echo $tahun ?></span>
        <?php
        }
        ?>
    </div>

    <?php
    $jml_data = count($pensiun);
    if ($jml_data > 0) { ?>
        <table class="table table-border table-striped" style="margin-bottom: 6rem;">
            <tr>
                <td class="text-center">No</td>
                <td class="text-center">Nama Personel</td>
                <td class="text-center">NRP/NIP</td>
                <td class="text-center">Usia</td>
                <td class="text-center">TMT Pensiun</td>
                <td class="text-center">Action</td>
            </tr>

            <?php $no = 1;
            foreach ($pensiun as $a) : ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $a->nama_personel ?></td>
                    <td><?php echo $a->NRP ?></td>
                    <td><?php echo $a->umur ?></td>
                    <td><?php echo $a->tmt_pensiun ?></td>
                    <td>
                        <center>
                            <a class="btn btn-sm btn-primary" href="<?php echo base_url('admin/prosesPensiun/updateData/' . $a->id_pensiun) ?>"><i class="fas fa-edit"></i></a>
                            <a onclick="return confirm('Yakin Hapus Data?')" class="btn btn-sm btn-danger" href="<?php echo base_url('admin/prosesPensiun/deleteData/' . $a->id_pensiun) ?>"><i class="fas fa-trash"></i></a>
                        </center>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>

    <?php } else { ?>
        <span class="badge badge-danger"><i class="fas fa-info-circle"></i> Data Masih Kosong, Silahkan Input Data pada bulan dan tahun yang dipilih </span>
    <?php } ?>

</div>