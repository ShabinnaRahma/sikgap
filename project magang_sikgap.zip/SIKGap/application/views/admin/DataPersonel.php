<div class="container-fluid">

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
</div>

<a class="btn btn-sm btn-success mb-3" href="<?php echo base_url('admin/dataPersonel/tambahData') ?>"><i class="fas fa-plus"></i> Tambah Data </a>
<?php echo $this->session->flashdata("pesan") ?>
<table class="table table-bordered table-striped mt-2">
    <tr>
        <th class="text-center">No</th>
        <th class="text-center">Nama Personel</th>
        <th class="text-center">Pangkat</th>
        <th class="text-center">NRP/NIP</th>
        <th class="text-center">Jabatan</th>
        <th class="text-center">Jenis Kelamin</th>
        <th class="text-center">Tanggal Lahir</th>
        <th class="text-center">Action</th>
    </tr>

    <?php $no=1; foreach($personel as $j) : ?>
        <tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $j->nama_personel ?></td>
            <td><?php echo $j->pangkat ?></td>
            <td><?php echo $j->NRP ?></td>
            <td><?php echo $j->jabatan ?></td>
            <td><?php echo $j->jenis_kelamin ?></td>
            <td><?php echo $j->tanggal_lahir ?></td>
            <td>
                <center>
                <a class="btn btn-sm btn-primary" href="<?php echo base_url('admin/dataPersonel/updateData/'.$j->id_personel) ?>"><i class="fas fa-edit"></i></a>
                <a onclick="return confirm('Yakin Hapus Data?')" class="btn btn-sm btn-danger" href="<?php echo base_url('admin/dataPersonel/deleteData/'.$j->id_personel) ?>"><i class="fas fa-trash"></i></a>
                </center>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
    

</div>