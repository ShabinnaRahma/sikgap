<!DOCTYPE html>
<html>

<head>
    <title><?php echo $title ?></title>
    <style type="text/css">
        body {
            font-family: Arial;
            color: black;
        }
    </style>
</head>

<body>

    <div class="row d-flex justify-content-center">
        <div class="mx-3    ">
            <img src="<?= base_url('assets/img/polda.png') ?>" style="width: 55px" alt="">
        </div>
        <div class="text-center mx-3    ">
            <span style="font-size: 13pt; margin: 0px; padding: 0px;">KEPOLISIAN NEGARA REPUBLIK INDONESIA</span><br>
            <span style="font-size: 13pt; margin: 0px; padding: 0px;">DAERAH JAWA TIMUR</span><br>
            <span style="font-size: 13pt; margin: 0px; padding: 0px;">BIDANG TEKNOLOGI INFORMASI DAN KOMUNIKASI</span><br>
        </div>
        <div class="mx-3    ">
            <img src="<?= base_url('assets/img/bid tik.png') ?>" style="width: 70px" alt="">
        </div>
    </div>

    <hr class="border-dark mb-5">

    <center>
        <h2>Laporan Pensiun</h2>
    </center>

    <?php
    $bulan = $this->input->post('bulan');
    $tahun = $this->input->post('tahun');
    ?>

    <table>
        <tr>
            <td>Bulan</td>
            <td>:</td>
            <td><?php echo $bulan ?></td>
        </tr>
        <tr>
            <td>Tahun</td>
            <td>:</td>
            <td><?php echo $tahun ?></td>
        </tr>
    </table>

    <table class="table table-bordered table-striped">
        <tr>
            <th>No</th>
            <th>Nama Personel</th>
            <th>NRP/NIP</th>
            <th>Usia</th>
            <th>TMT Pensiun</th>
        </tr>
        <?php $no = 1;
        foreach ($lap_pensiun as $l) : ?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $l->nama_personel ?></td>
                <td><?php echo $l->NRP ?></td>
                <td><?php echo $l->usia ?></td>
                <td><?php echo $l->tmt_pensiun ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

</body>

</html>

<script type="text/javascript">
    window.print();
</script>