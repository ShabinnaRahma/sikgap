<?php

class sikgapModel extends CI_model
{

    public function get_data($table)
    {
        return $this->db->get($table);
    }

    public function insert_data($data, $table)
    {
        $this->db->insert($table, $data);
    }

    public function update_data($table, $data, $where)
    {
        $this->db->update($table, $data, $where);
    }

    public function delete_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }

    public function insert_batch($table = null, $data = array())
    {
        $jumlah = count($data);
        if ($jumlah > 0) {
            $this->db->insert_batch($table, $data);
        }
    }

    public function cek_login($NRP, $password)
    {
        $result = $this->db->where('NRP', $NRP)
            ->where('password', md5($password))
            ->limit(1)
            ->get('data_admin');

        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return FALSE;
        }
    }

    public function getNotification()
    {
        date_default_timezone_set('Asia/Jakarta');
        $three_months_ahead = date('Y-m-d', strtotime('+90 days')); // KGB 3 bulan ke depan
        $six_months_ahead = date('Y-m-d', strtotime('+180 days')); // Pangkat dan Pensiun 6 bulan ke depan
        $today = date('Y-m-d');

        // Gabungkan hasil query menggunakan UNION
        $query = $this->db->query(
            "SELECT 'KGB' as source, DATE_FORMAT(berkala_selanjutnya, '%d-%m-%Y') as date, NRP, berkala_selanjutnya, bulan, nama_personel
             FROM proses_KGB
             WHERE berkala_selanjutnya BETWEEN '$today' AND '$three_months_ahead'
             UNION ALL
             SELECT 'Pangkat' as source, DATE_FORMAT(tmt_selanjutnya, '%d-%m-%Y') as date, NRP, tmt_selanjutnya, bulan, nama_personel
             FROM proses_pangkat
             WHERE tmt_selanjutnya BETWEEN '$today' AND '$six_months_ahead'
             UNION ALL
             SELECT 'Pensiun' as source, DATE_FORMAT(tmt_pensiun, '%d-%m-%Y') as date, NRP, tmt_pensiun, bulan, nama_personel
             FROM proses_pensiun
             WHERE tmt_pensiun BETWEEN '$today' AND '$six_months_ahead'
             ORDER BY STR_TO_DATE(date, '%d-%m-%Y') ASC"
        );

        $data['notifications'] = $query->result();

        // Calculate days remaining and check if the date is today
        foreach ($data['notifications'] as $item) {
            $notification_date = DateTime::createFromFormat('d-m-Y', $item->date);
            $today_date = new DateTime();
            $interval = $today_date->diff($notification_date);
            $days_remaining = $interval->format('%a');

            if ($days_remaining  == 0) {
                $item->remaining_days = 'Hari ini';
            } else {
                $item->remaining_days = $days_remaining . ' hari lagi';
            }
        }

        // Total jumlah hasil
        $data['total'] = count($data['notifications']);

        return $data;
    }

    public function get_password_hash($id_admin)
    {
        $this->db->select('password');
        $this->db->from('data_admin');
        $this->db->where('id_admin', $id_admin);
        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->row()->password;
        } else {
            return FALSE;
        }
    }

    public function update_password($new_hashes_password, $id_admin)
    {
        $this->db->where('id_admin', $id_admin);
        $this->db->update('data_admin', array('password' => $new_hashes_password));
    }
}
