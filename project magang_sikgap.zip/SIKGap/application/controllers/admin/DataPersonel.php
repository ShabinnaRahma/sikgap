<?php

class DataPersonel extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('hak_akses') != '1') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          	  	 <strong>Anda belum login!!</strong> 
           		 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              	 <span aria-hidden="true">&times;</span>
            	 </button>
          		 </div>');
            redirect('welcome');
        }
    }

    public function index()
    {
        $data['title'] = "Data Personel";
        $data['personel'] = $this->sikgapModel->get_data('data_personel')->result();
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/dataPersonel', $data);
        $this->load->view('templates_admin/footer');
    }

    public function tambahData()
    {
        $data['title'] = "Tambah Data Personel";
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/tambahDataPersonel', $data);
        $this->load->view('templates_admin/footer');
    }

    public function tambahDataAksi()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->tambahData();
        } else {
            $nama_personel           = $this->input->post('nama_personel');
            $pangkat                 = $this->input->post('pangkat');
            $NRP                     = $this->input->post('NRP');
            $jabatan                 = $this->input->post('jabatan');
            $jenis_kelamin           = $this->input->post('jenis_kelamin');
            $tanggal_lahir           = $this->input->post('tanggal_lahir');

            $data = array(
                'nama_personel'     => $nama_personel,
                'pangkat'           => $pangkat,
                'NRP'               => $NRP,
                'jabatan'           => $jabatan,
                'jenis_kelamin'     => $jenis_kelamin,
                'tanggal_lahir'     => $tanggal_lahir,
            );

            $this->sikgapModel->insert_data($data, 'data_personel');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil ditambahkan !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/dataPersonel');
        }
    }

    public function updateData($id)
    {
        $where = array('id_personel' => $id);
        $data['personel'] = $this->db->query("SELECT * FROM data_personel WHERE id_personel= '$id'")->result();
        $data['title'] = "Update Data Personel";
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/updateDataPersonel', $data);
        $this->load->view('templates_admin/footer');
    }

    public function updateDataAksi()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->updateData();
        } else {
            $id                      = $this->input->post('id_personel');
            $nama_personel           = $this->input->post('nama_personel');
            $pangkat                 = $this->input->post('pangkat');
            $NRP                     = $this->input->post('NRP');
            $jabatan                 = $this->input->post('jabatan');
            $jenis_kelamin           = $this->input->post('jenis_kelamin');
            $tanggal_lahir           = $this->input->post('tanggal_lahir');

            $data = array(
                'nama_personel'     => $nama_personel,
                'pangkat'           => $pangkat,
                'NRP'               => $NRP,
                'jabatan'           => $jabatan,
                'jenis_kelamin'     => $jenis_kelamin,
                'tanggal_lahir'     => $tanggal_lahir,
            );

            $where = array(
                'id_personel' => $id
            );


            $this->sikgapModel->update_data('data_personel', $data, $where);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil diupdate!</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/dataPersonel');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('NRP', 'NRP', 'required');
        $this->form_validation->set_rules('jabatan', 'jabatan', 'required');
        $this->form_validation->set_rules('pangkat', 'pangkat', 'required');
    }

    public function deleteData($id)
    {
        $where = array('id_personel' => $id);
        $this->sikgapModel->delete_data($where, 'data_personel');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Data berhasil dihapus !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
        redirect('admin/dataPersonel');
    }
}
