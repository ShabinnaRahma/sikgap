<?php

class DataAdmin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('hak_akses') != '1') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          	  	 <strong>Anda belum login!!</strong> 
           		 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              	 <span aria-hidden="true">&times;</span>
            	 </button>
          		 </div>');
            redirect('welcome');
        }
    }

    public function index()
    {
        $data['title'] = "Data Admin";
        $data['admin'] = $this->sikgapModel->get_data('data_admin')->result();
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/dataAdmin', $data);
        $this->load->view('templates_admin/footer');
    }

    public function tambahData()
    {
        $data['title'] = "Tambah Data Admin";
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/tambahDataAdmin', $data);
        $this->load->view('templates_admin/footer');
    }

    public function tambahDataAksi()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->tambahData();
        } else {
            $nama_admin              = $this->input->post('nama_admin');
            $NRP                     = $this->input->post('NRP');
            $hak_akses               = $this->input->post('hak_akses');
            $password                = md5($this->input->post('password'));

            $data = array(
                'nama_admin'            => $nama_admin,
                'NRP'                   => $NRP,
                'hak_akses'             => $hak_akses,
                'password'              => $password,
            );

            $this->sikgapModel->insert_data($data, 'data_admin');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil ditambahkan !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/dataAdmin');
        }
    }

    public function updateData($id)
    {
        $where = array('id_admin' => $id);
        $data['admin'] = $this->db->query("SELECT * FROM data_admin WHERE id_admin= '$id'")->result();
        $data['title'] = "Update Data Admin";
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/updateDataAdmin', $data);
        $this->load->view('templates_admin/footer');
    }

    public function updateDataAksi()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->updateData();
        } else {
            $id                      = $this->input->post('id_admin');
            $nama_admin              = $this->input->post('nama_admin');
            $NRP                     = $this->input->post('NRP');
            $hak_akses               = $this->input->post('hak_akses');
            $password                = md5($this->input->post('password'));


            $data = array(
                'nama_admin'            => $nama_admin,
                'NRP'                   => $NRP,
                'hak_akses'             => $hak_akses,
                'password'              => $password,
            );

            $where = array(
                'id_admin' => $id
            );


            $this->sikgapModel->update_data('data_admin', $data, $where);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil diupdate!</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/dataAdmin');
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('nama_admin', 'nama_admin', 'required');
        $this->form_validation->set_rules('NRP', 'NRP', 'required');
        $this->form_validation->set_rules('hak_akses', 'hak_akses', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
    }

    public function deleteData($id)
    {
        $where = array('id_admin' => $id);
        $this->sikgapModel->delete_data($where, 'data_admin');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Data berhasil dihapus !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
        redirect('admin/dataAdmin');
    }
}
