<?php

class prosesKGB extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('hak_akses') != '1') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          	  	 <strong>Anda belum login!!</strong> 
           		 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              	 <span aria-hidden="true">&times;</span>
            	 </button>
          		 </div>');
            redirect('welcome');
        }
    }

    public function index()
    {
        $data['title'] = "Proses Kenaikan Gaji Berkala";

        if (!empty($this->input->get('bulan')) && !empty($this->input->get('tahun'))) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $bulantahun = $bulan . $tahun;
        } else if (empty($this->input->get('bulan')) && !empty($this->input->get('tahun'))) {
            $tahun = $_GET['tahun'];
        } else if (!empty($this->input->get('bulan')) && empty($this->input->get('tahun'))) {
            $bulan = $_GET['bulan'];
            $tahun = date('Y');
            $bulantahun = $bulan . $tahun;
        } else {
            $bulan = date('m');
            $tahun = date('Y');
            $bulantahun = $bulan . $tahun;
        }

        $nrp = $this->input->get('nrp');
        $nama = $this->input->get('nama');

        if (!empty($nrp) && !empty($nama)) {
            // Jika search berdasarkan NRP dan Nama 
            $data['nrp'] = $nrp;
            $data['nama'] = $nama;
            $data['kgb'] = $this->db->query(
                "SELECT proses_kgb.*, data_personel.nama_personel, data_personel.pangkat, data_personel.jabatan
                 FROM proses_kgb
                 INNER JOIN data_personel ON proses_kgb.NRP = data_personel.NRP
                 WHERE data_personel.NRP = '$nrp' AND LOWER(data_personel.nama_personel) LIKE LOWER(CONCAT('%', '$nama', '%'))
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else if (!empty($nrp) && empty($nama)) {
            // Jika search berdasarkan NRP
            $data['nrp'] = $nrp;
            $data['kgb'] = $this->db->query(
                "SELECT proses_kgb.*, data_personel.nama_personel, data_personel.pangkat, data_personel.jabatan
                 FROM proses_kgb
                 INNER JOIN data_personel ON proses_kgb.NRP = data_personel.NRP
                 WHERE data_personel.NRP = '$nrp'
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else if (empty($nrp) && !empty($nama)) {
            // Jika search berdasarkan Nama
            $data['nama'] = $nama;
            $data['kgb'] = $this->db->query(
                "SELECT proses_kgb.*, data_personel.nama_personel, data_personel.pangkat, data_personel.jabatan
                 FROM proses_kgb
                 INNER JOIN data_personel ON proses_kgb.NRP = data_personel.NRP
                 WHERE LOWER(data_personel.nama_personel) LIKE LOWER(CONCAT('%', '$nama', '%'))
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else if (empty($bulan) && !empty($tahun)) {
            // Jika search berdasarkan Tahun
            $data['tahun'] = $tahun;
            $data['kgb'] = $this->db->query(
                "SELECT proses_kgb.*, data_personel.nama_personel, data_personel.pangkat, data_personel.jabatan
                 FROM proses_kgb
                 INNER JOIN data_personel ON proses_kgb.NRP = data_personel.NRP
                 WHERE RIGHT(bulan, 4) = '$tahun'
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else {
            // Jika search berdasarkan Bulan dan Tahun
            $data['bulan'] = $bulan;
            $data['tahun'] = $tahun;
            $data['kgb'] = $this->db->query(
                "SELECT proses_kgb.*, data_personel.nama_personel, data_personel.pangkat, data_personel.jabatan
                FROM proses_kgb
                INNER JOIN data_personel ON proses_kgb.NRP=data_personel.NRP
                WHERE proses_kgb.bulan='$bulantahun'
                ORDER BY data_personel.nama_personel ASC"
            )->result();
        }

        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/prosesKgb', $data);
        $this->load->view('templates_admin/footer');
    }

    public  function inputKGB()
    {
        if ($this->input->post('submit', TRUE) == 'submit') {

            $post = $this->input->post();

            foreach ($post['bulan'] as $key => $value) {
                if ($post['bulan'][$key] != '' || $post['NRP'][$key] != '') {
                    $simpan[] = array(
                        'bulan'                  => $post['bulan'][$key],
                        'nama_personel'          => $post['nama_personel'][$key],
                        'pangkat'                => $post['pangkat'][$key],
                        'NRP'                    => $post['NRP'][$key],
                        'jabatan'                => $post['jabatan'][$key],
                        'berkala_terakhir'       => $post['berkala_terakhir'][$key],
                        'berkala_selanjutnya'    => $post['berkala_selanjutnya'][$key]
                    );
                }
            }

            $this->sikgapModel->insert_batch('proses_kgb', $simpan);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil ditambahkan !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/prosesKgb');
        }

        $data['title'] = "Form Input Kenaikan Gaji Berkala";
        if ((isset($_GET['bulan']) && $_GET['bulan'] != '') && (isset($_GET['tahun']) && $_GET['tahun'] != '')) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $bulantahun = $bulan . $tahun;
        } else {
            $bulan = date('m');
            $tahun = date('Y');
            $bulantahun = $bulan . $tahun;
        }
        $data['input_kgb'] = $this->db->query("SELECT data_personel.*, data_personel.jabatan FROM data_personel
        WHERE NOT EXISTS (SELECT * FROM proses_kgb WHERE bulan='$bulantahun' AND data_personel.NRP=proses_kgb.NRP) ORDER BY data_personel.nama_personel ASC")->result();
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/formInputKGB', $data);
        $this->load->view('templates_admin/footer');
    }

    public function updateData($id)
    {
        $where = array('id_kgb' => $id);
        $data['kgb'] = $this->db->query("SELECT * FROM proses_kgb WHERE id_kgb= '$id'")->result();
        $data['title'] = "Update Proses KGB";
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/updateProsesKGB', $data);
        $this->load->view('templates_admin/footer');
    }

    public function updateDataAksi()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->updateData();
        } else {
            $id                      = $this->input->post('id_kgb');
            $nama_personel           = $this->input->post('nama_personel');
            $pangkat                 = $this->input->post('pangkat');
            $NRP                     = $this->input->post('NRP');
            $jabatan                 = $this->input->post('jabatan');
            $berkala_terakhir        = $this->input->post('berkala_terakhir');
            $berkala_selanjutnya     = $this->input->post('berkala_selanjutnya');

            $data = array(
                'nama_personel'         => $nama_personel,
                'pangkat'               => $pangkat,
                'NRP'                   => $NRP,
                'jabatan'               => $jabatan,
                'berkala_terakhir'      => $berkala_terakhir,
                'berkala_selanjutnya'   => $berkala_selanjutnya,
            );

            $where = array(
                'id_kgb' => $id
            );


            $this->sikgapModel->update_data('proses_kgb', $data, $where);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil diupdate!</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/prosesKgb');
        }
    }

    public function deleteData($id)
    {
        $where = array('id_kgb' => $id);
        $this->sikgapModel->delete_data($where, 'proses_kgb');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Data berhasil dihapus !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
        redirect('admin/prosesKgb');
    }
}
