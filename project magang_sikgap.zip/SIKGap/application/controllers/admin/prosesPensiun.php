<?php

class prosesPensiun extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('hak_akses') != '1') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          	  	 <strong>Anda belum login!!</strong> 
           		 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              	 <span aria-hidden="true">&times;</span>
            	 </button>
          		 </div>');
            redirect('welcome');
        }
    }

    public function index()
    {
        $data['title'] = "Proses Pensiun";

        if (!empty($this->input->get('bulan')) && !empty($this->input->get('tahun'))) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $bulantahun = $bulan . $tahun;
        } else if (empty($this->input->get('bulan')) && !empty($this->input->get('tahun'))) {
            $tahun = $_GET['tahun'];
        } else if (!empty($this->input->get('bulan')) && empty($this->input->get('tahun'))) {
            $bulan = $_GET['bulan'];
            $tahun = date('Y');
            $bulantahun = $bulan . $tahun;
        } else {
            $bulan = date('m');
            $tahun = date('Y');
            $bulantahun = $bulan . $tahun;
        }

        $nrp = $this->input->get('nrp');
        $nama = $this->input->get('nama');

        if (!empty($nrp) && !empty($nama)) {
            // Jika search berdasarkan NRP dan Nama 
            $data['nrp'] = $nrp;
            $data['nama'] = $nama;
            $data['pensiun'] = $this->db->query(
                "SELECT *
                 FROM proses_pensiun
                 INNER JOIN data_personel ON proses_pensiun.NRP = data_personel.NRP
                 WHERE data_personel.NRP = '$nrp' AND LOWER(data_personel.nama_personel) LIKE LOWER(CONCAT('%', '$nama', '%'))
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else if (!empty($nrp) && empty($nama)) {
            // Jika search berdasarkan NRP
            $data['nrp'] = $nrp;
            $data['pensiun'] = $this->db->query(
                "SELECT *
                 FROM proses_pensiun
                 INNER JOIN data_personel ON proses_pensiun.NRP = data_personel.NRP
                 WHERE data_personel.NRP = '$nrp'
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else if (empty($nrp) && !empty($nama)) {
            // Jika search berdasarkan Nama
            $data['nama'] = $nama;
            $data['pensiun'] = $this->db->query(
                "SELECT *
                 FROM proses_pensiun
                 INNER JOIN data_personel ON proses_pensiun.NRP = data_personel.NRP
                 WHERE LOWER(proses_pensiun.nama_personel) LIKE LOWER(CONCAT('%', '$nama', '%'))
                 ORDER BY proses_pensiun.nama_personel ASC"
            )->result();
        } else if (empty($bulan) && !empty($tahun)) {
            // Jika search berdasarkan Tahun
            $data['tahun'] = $tahun;
            $data['pensiun'] = $this->db->query(
                "SELECT *
                 FROM proses_pensiun
                 INNER JOIN data_personel ON proses_pensiun.NRP = data_personel.NRP
                 WHERE RIGHT(proses_pensiun.bulan, 4) = '$tahun'
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else {
            // Jika search berdasarkan Bulan dan Tahun
            $data['bulan'] = $bulan;
            $data['tahun'] = $tahun;
            $data['pensiun'] = $this->db->query(
                "SELECT *
                FROM proses_pensiun
                INNER JOIN data_personel ON data_personel.NRP = proses_pensiun.NRP
                WHERE proses_pensiun.bulan='$bulantahun'
                ORDER BY data_personel.nama_personel ASC"
            )->result();
        }

        date_default_timezone_set('Asia/Jakarta');

        $current_date = new DateTime();

        foreach ($data['pensiun'] as &$pensiun) {
            $birth_date = new DateTime($pensiun->tanggal_lahir);
            $pensiun->umur = $current_date->diff($birth_date)->y;
        }

        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());
        $this->load->view('admin/prosesPensiun', $data);
        $this->load->view('templates_admin/footer');
    }

    public  function inputPensiun()
    {
        if ($this->input->post('submit', TRUE) == 'submit') {

            $post = $this->input->post();

            foreach ($post['bulan'] as $key => $value) {
                if ($post['bulan'][$key] != '' || $post['NRP'][$key] != '') {
                    $simpan[] = array(
                        'bulan'                  => $post['bulan'][$key],
                        'nama_personel'          => $post['nama_personel'][$key],
                        'NRP'                    => $post['NRP'][$key],
                        'usia'                   => $post['usia'][$key],
                        'tmt_pensiun'           => $post['tmt_pensiun'][$key],
                    );
                }
            }

            $this->sikgapModel->insert_batch('proses_pensiun', $simpan);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil ditambahkan !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/prosesPensiun');
        }

        $data['title'] = "Form Input Pensiun";
        if ((isset($_GET['bulan']) && $_GET['bulan'] != '') && (isset($_GET['tahun']) && $_GET['tahun'] != '')) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $bulantahun = $bulan . $tahun;
        } else {
            $bulan = date('m');
            $tahun = date('Y');
            $bulantahun = $bulan . $tahun;
        }
        $data['input_pensiun'] = $this->db->query("SELECT data_personel.*, data_personel.NRP FROM data_personel
        WHERE NOT EXISTS (SELECT * FROM proses_pensiun WHERE bulan='$bulantahun' AND data_personel.NRP=proses_pensiun.NRP) ORDER BY data_personel.nama_personel ASC")->result();
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/formInputPensiun', $data);
        $this->load->view('templates_admin/footer');
    }

    public function updateData($id)
    {
        $where = array('id_pensiun' => $id);
        $data['pensiun'] = $this->db->query("SELECT * FROM proses_pensiun WHERE id_pensiun= '$id'")->result();
        $data['title'] = "Update Proses Pensiun";
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/updateProsesPensiun', $data);
        $this->load->view('templates_admin/footer');
    }

    public function updateDataAksi()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->updateData();
        } else {
            $id                      = $this->input->post('id_kp');
            $nama_personel           = $this->input->post('nama_personel');
            $NRP                     = $this->input->post('NRP');
            $usia                    = $this->input->post('usia');
            $tmt_pensiun            = $this->input->post('tmt_pensiun');

            $data = array(
                'nama_personel'         => $nama_personel,
                'pangkat'               => $pangkat,
                'NRP'                   => $NRP,
                'usia'                  => $usia,
                'tmt_pensiun'           => $tmt_pensiun,
            );

            $where = array(
                'id_pensiun' => $id
            );


            $this->sikgapModel->update_data('proses_pensiun', $data, $where);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil diupdate!</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/prosesPensiun');
        }
    }

    public function deleteData($id)
    {
        $where = array('id_pensiun' => $id);
        $this->sikgapModel->delete_data($where, 'proses_pensiun');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Data berhasil dihapus !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
        redirect('admin/prosesPensiun');
    }
}
