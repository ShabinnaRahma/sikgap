<?php

class prosesPangkat extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('hak_akses') != '1') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          	  	 <strong>Anda belum login!!</strong> 
           		 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              	 <span aria-hidden="true">&times;</span>
            	 </button>
          		 </div>');
            redirect('welcome');
        }
    }

    public function index()
    {
        $data['title'] = "Proses Kenaikan Pangkat";

        if (!empty($this->input->get('bulan')) && !empty($this->input->get('tahun'))) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $bulantahun = $bulan . $tahun;
        } else if (empty($this->input->get('bulan')) && !empty($this->input->get('tahun'))) {
            $tahun = $_GET['tahun'];
        } else if (!empty($this->input->get('bulan')) && empty($this->input->get('tahun'))) {
            $bulan = $_GET['bulan'];
            $tahun = date('Y');
            $bulantahun = $bulan . $tahun;
        } else {
            $bulan = date('m');
            $tahun = date('Y');
            $bulantahun = $bulan . $tahun;
        }

        $nrp = $this->input->get('nrp');
        $nama = $this->input->get('nama');

        if (!empty($nrp) && !empty($nama)) {
            // Jika search berdasarkan NRP dan Nama 
            $data['nrp'] = $nrp;
            $data['nama'] = $nama;
            $data['pangkat'] = $this->db->query(
                "SELECT proses_pangkat.*, data_personel.nama_personel, data_personel.pangkat
                 FROM proses_pangkat
                 INNER JOIN data_personel ON proses_pangkat.NRP = data_personel.NRP
                 WHERE data_personel.NRP = '$nrp' AND LOWER(data_personel.nama_personel) LIKE LOWER(CONCAT('%', '$nama', '%'))
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else if (!empty($nrp) && empty($nama)) {
            // Jika search berdasarkan NRP
            $data['nrp'] = $nrp;
            $data['pangkat'] = $this->db->query(
                "SELECT proses_pangkat.*, data_personel.nama_personel, data_personel.pangkat
                 FROM proses_pangkat
                 INNER JOIN data_personel ON proses_pangkat.NRP = data_personel.NRP
                 WHERE data_personel.NRP = '$nrp'
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else if (empty($nrp) && !empty($nama)) {
            // Jika search berdasarkan Nama
            $data['nama'] = $nama;
            $data['pangkat'] = $this->db->query(
                "SELECT proses_pangkat.*, data_personel.nama_personel, data_personel.pangkat
                 FROM proses_pangkat
                 INNER JOIN data_personel ON proses_pangkat.NRP = data_personel.NRP
                 WHERE LOWER(data_personel.nama_personel) LIKE LOWER(CONCAT('%', '$nama', '%'))
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else if (empty($bulan) && !empty($tahun)) {
            // Jika search berdasarkan Tahun
            $data['tahun'] = $tahun;
            $data['pangkat'] = $this->db->query(
                "SELECT proses_pangkat.*, data_personel.nama_personel, data_personel.pangkat
                 FROM proses_pangkat
                 INNER JOIN data_personel ON proses_pangkat.NRP = data_personel.NRP
                 WHERE RIGHT(bulan, 4) = '$tahun'
                 ORDER BY data_personel.nama_personel ASC"
            )->result();
        } else {
            // Jika search berdasarkan Bulan dan Tahun
            $data['bulan'] = $bulan;
            $data['tahun'] = $tahun;
            $data['pangkat'] = $this->db->query(
                "SELECT proses_pangkat.*, data_personel.nama_personel, data_personel.pangkat
                FROM proses_pangkat
                INNER JOIN data_personel ON proses_pangkat.NRP=data_personel.NRP
                WHERE proses_pangkat.bulan='$bulantahun'
                ORDER BY data_personel.nama_personel ASC"
            )->result();
        }

        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/prosesPangkat', $data);
        $this->load->view('templates_admin/footer');
    }

    public  function inputPangkat()
    {
        if ($this->input->post('submit', TRUE) == 'submit') {

            $post = $this->input->post();

            foreach ($post['bulan'] as $key => $value) {
                if ($post['bulan'][$key] != '' || $post['NRP'][$key] != '') {
                    $simpan[] = array(
                        'bulan'                  => $post['bulan'][$key],
                        'nama_personel'          => $post['nama_personel'][$key],
                        'NRP'                    => $post['NRP'][$key],
                        'pangkat_terakhir'       => $post['pangkat_terakhir'][$key],
                        'tmt_terakhir'           => $post['tmt_terakhir'][$key],
                        'pangkat_selanjutnya'    => $post['pangkat_selanjutnya'][$key],
                        'tmt_selanjutnya'        => $post['tmt_selanjutnya'][$key],
                    );
                }
            }

            $this->sikgapModel->insert_batch('proses_pangkat', $simpan);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil ditambahkan !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/prosesPangkat');
        }

        $data['title'] = "Form Input Kenaikan Pangkat";
        if ((isset($_GET['bulan']) && $_GET['bulan'] != '') && (isset($_GET['tahun']) && $_GET['tahun'] != '')) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $bulantahun = $bulan . $tahun;
        } else {
            $bulan = date('m');
            $tahun = date('Y');
            $bulantahun = $bulan . $tahun;
        }
        $data['input_pangkat'] = $this->db->query("SELECT data_personel.*, data_personel.jabatan FROM data_personel
        WHERE NOT EXISTS (SELECT * FROM proses_pangkat WHERE bulan='$bulantahun' AND data_personel.NRP=proses_pangkat.NRP) ORDER BY data_personel.nama_personel ASC")->result();
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/formInputPangkat', $data);
        $this->load->view('templates_admin/footer');
    }

    public function updateData($id)
    {
        $where = array('id_kp' => $id);
        $data['pangkat'] = $this->db->query("SELECT * FROM proses_pangkat WHERE id_kp= '$id'")->result();
        $data['title'] = "Update Proses Kenaikan Pangkat";
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('admin/updateProsesPangkat', $data);
        $this->load->view('templates_admin/footer');
    }

    public function updateDataAksi()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->updateData();
        } else {
            $id                      = $this->input->post('id_kp');
            $nama_personel           = $this->input->post('nama_personel');
            $NRP                     = $this->input->post('NRP');
            $pangkat_terakhir        = $this->input->post('berkala_terakhir');
            $tmt_terakhir            = $this->input->post('tmt_terakhir');
            $pangkat_selanjutnya     = $this->input->post('pangkat_selanjutnya');
            $tmt_selanjutnya         = $this->input->post('tmt_selanjutnya');

            $data = array(
                'nama_personel'         => $nama_personel,
                'pangkat'               => $pangkat,
                'NRP'                   => $NRP,
                'pangkat_terakhir'      => $pangkat_terakhir,
                'tmt_terakhir'          => $tmt_terakhir,
                'pangkat_selanjutnya'   => $pangkat_selanjutnya,
                'tmt_terakhir'          => $tmt_terakhir,
            );

            $where = array(
                'id_kp' => $id
            );


            $this->sikgapModel->update_data('proses_pangkat', $data, $where);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data berhasil diupdate!</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('admin/prosesPangkat');
        }
    }

    public function deleteData($id)
    {
        $where = array('id_kp' => $id);
        $this->sikgapModel->delete_data($where, 'proses_pangkat');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Data berhasil dihapus !</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
        redirect('admin/prosesPangkat');
    }
}
