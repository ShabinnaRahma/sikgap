<?php

class GantiPassword extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('hak_akses') != '1') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          	  	 <strong>Anda belum login!!</strong> 
           		 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              	 <span aria-hidden="true">&times;</span>
            	 </button>
          		 </div>');
            redirect('welcome');
        }
    }

    public function index()
    {
        $data['title'] = "Ganti Password";
        $this->load->view('templates_admin/header', $data);
        $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
        $this->load->view('formGantiPassword', $data);
        $this->load->view('templates_admin/footer');
    }

    public function gantiPasswordAksi()
    {
        $passBaru = $this->input->post('passBaru');

        $this->form_validation->set_rules('passLama', 'password lama', 'required|callback_check_old_password');
        $this->form_validation->set_rules('passBaru', 'password baru', 'required');
        $this->form_validation->set_rules('ulangPass', 'ulangi password', 'required|matches[passBaru]');

        if ($this->form_validation->run() != FALSE) {
            $this->sikgapModel->update_password(md5($passBaru), $this->session->userdata('id_admin'));
            $this->session->unset_userdata('id_admin');
            $this->session->unset_userdata('hak_akses');
            $this->session->unset_userdata('nama_admin');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Password Berhasil diganti!</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');
            redirect('welcome');
        } else {
            $data['title'] = "Ganti Password";
            $this->load->view('templates_admin/header', $data);
            $this->load->view('templates_admin/sidebar', $this->sikgapModel->getNotification());;
            $this->load->view('formGantiPassword', $data);
            $this->load->view('templates_admin/footer');
        }
    }

    public function check_old_password($passLama)
    {
        $id_admin = $this->session->userdata('id_admin');
        $stored_password_hash = $this->sikgapModel->get_password_hash($id_admin);

        if (md5($passLama) == $stored_password_hash) {
            return TRUE;
        } else {
            $this->form_validation->set_message('check_old_password', 'Password lama salah.');
            return FALSE;
        }
    }
}
